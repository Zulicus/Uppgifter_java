package uppgift5;

public class Person {
	int age;
	String name;
	String surname;
	String middlename;
	boolean likesChristmas;

	public Person(int age, String name, String surname, String middlename, boolean likesChristmas) {
		this.age = age;
		this.name = name;
		this.surname = surname;
		this.middlename = middlename;
		this.likesChristmas = likesChristmas;
	}
}
